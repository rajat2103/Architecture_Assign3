// Create other necessary functions here
//
#include<iostream>


__global__ void cudaGPU(int *a, int *b, int *c, int N){


	int row = blockIdx.y * blockDim.y + threadIdx.y;
  	int col = blockIdx.x * blockDim.x + threadIdx.x;
  
 	c[row * N + col] = 0;

	int n = 2*N;
	int sum = 0;
  	for(int k=0;k<n;k++){
  	
  	            sum += a[(2*row * n) + k] * b[k * n + (2*col)];
  	            sum += a[((2*row+1) * n) + k] * b[k * n + (2*col)];
  	            sum += a[(2*row * n) + k] * b[k * n + (2*col + 1)];
  	            sum+= a[((2*row+1) * n) + k] * b[k * n + (2*col + 1)];
  		
  	}
	c[row*N + col] = sum;	
}

// Fill in this function
void gpuThread(int N, int *matA, int *matB, int *output)
{
	cout<<"HELLO "<<endl;
  size_t bytes=N*N*sizeof(int);		
  
  int *cudaA, *cudaB, *cudaO;	
  
  cudaMallocManaged(&cudaA, bytes);	
  cudaMallocManaged(&cudaB, bytes);
  cudaMallocManaged(&cudaO, (bytes/4));
  
  // Copy data to the device
  cudaMemcpy(cudaA, matA, bytes, cudaMemcpyHostToDevice);
  cudaMemcpy(cudaB, matB, bytes, cudaMemcpyHostToDevice);
  
 
  int THREADS = 32;     

   int BLOCKS = N/(2*THREADS) ;

  dim3 thrs(THREADS, THREADS);
  dim3 blck(BLOCKS, BLOCKS);    
  
  // Launch kernel

  cudaGPU<<<blck, thrs>>>(cudaA, cudaB, cudaO, N/2);

  cudaMemcpy(output, cudaO, bytes/4, cudaMemcpyDeviceToHost);

  // Free memory on device
  cudaFree(cudaA);
  cudaFree(cudaB);
  cudaFree(cudaO);
}
