// Optimize this function
#include <immintrin.h>
#include<smmintrin.h>
//#include<iostream>

void singleThread(int N, int *matA, int *matB, int *output)
{

  printf("Checking Normal Single thread..");
  assert( N>=4 and N == ( N &~ (N-1)));
  


  int*Y  = new int[N*N/2];
   int*X  = new int[N*N/2];
 
   
   for(int i=0;i<N;i+=2){
   
   	for(int j=0;j<N;j++){
   		Y[i/2*N + j] = matB[j*N + i] + matB[j*N +i +1];
   	}
   }
   
   for(int i=0;i<N;i+=2){
   
   	for(int j=0;j<N;j++){
   		X[i/2*N + j] = matA[i*N +j] + matA[(i+1)*N +j];
   	}
   }
   


	for(int i = 0;i<(N*N)/4;i++){
	  output[i] = 0;
	}
	
    int tmp[8];
    
    for(int i=0;i<N/2;i++){


  for(int j=0;j<N;j+=8){
  	


    __m256i mula = _mm256_loadu_si256((__m256i *)&X[i*N + j]);
   
    for(int rb =0;rb<N/2;rb ++){
      __m256i mulb = _mm256_loadu_si256((__m256i *)&Y[rb*N + j]);
      __m256i mul = _mm256_mullo_epi32(mula, mulb);
       _mm256_storeu_si256((__m256i *)&tmp, mul);
     
      
      int sum = 0;
      for(int l=0;l<8;l++){
        sum+= tmp[l];
      }
      output[(i*N/2 + rb)] += sum;
      
    }
    }
    }

	
	}
