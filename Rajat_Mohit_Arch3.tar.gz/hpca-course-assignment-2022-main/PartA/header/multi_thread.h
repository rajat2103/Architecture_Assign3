#include <pthread.h>
#include <immintrin.h>
#include<smmintrin.h>

// Create other necessary functions here

struct specs{
	int begin;
	int end;
	int N;
	int *matA;
	int *matB;
	int *output;
};

void *perThread(void* pthr){

//assert( N>=4 and N == ( N &~ (N-1)));

	struct specs *p = (struct specs*)pthr;
	int start = p->begin;
	int end = p->end;
	int N = p->N;
	int *matA = p->matA;
	int *matB = p->matB;
	int *output = p->output;
  


	int tmp[8];	
		for(int i=start;i<end;i++){


  for(int j=0;j<N;j+=8){
  	
	

    __m256i mula = _mm256_loadu_si256((__m256i *)&matA[i*N + j]);
   
    for(int rb =0;rb<N/2;rb ++){
      __m256i mulb = _mm256_loadu_si256((__m256i *)&matB[rb*N + j]);
      __m256i mul = _mm256_mullo_epi32(mula, mulb);
       _mm256_storeu_si256((__m256i *)&tmp, mul);
    
      
      int sum = 0;
      for(int l=0;l<8;l++){
        sum+= tmp[l];
      }
      output[(i*N/2 + rb)] += sum;
      
    }
    }
    }
  pthread_exit(NULL);
}


// Fill in this function
void multiThread(int N, int *matA, int *matB, int *output)
{
	
    int THREADS = 4;
    cout<<"Number of threads: "<<THREADS<<endl;
    pthread_t threads[THREADS];
	int diff = N/(2*THREADS);
	struct specs p[THREADS];
	
	int*Y  = new int[N*N/2];
   	int*X  = new int[N*N/2];
	
	for(int i=0;i<N;i+=2){
   
   	for(int j=0;j<N;j++){
   		Y[i/2*N + j] = matB[j*N + i] + matB[j*N +i +1];
   	}
   }
   
   for(int i=0;i<N;i+=2){
   
   	for(int j=0;j<N;j++){
   		X[i/2*N + j] = matA[i*N +j] + matA[(i+1)*N +j];
   	}
   }

	int count = 0;
	for(int i=0;i<THREADS;i++){
		p[i].begin = count;
		count += diff;
		p[i].end = count;
		p[i].N = N;
		p[i].matA = X;
		p[i].matB = Y;
		p[i].output = output;
	}

	for(int i=0;i<THREADS;i++){
			pthread_create( &threads[i], NULL, perThread, (void*) &p[i]);
	}
		
	for(int i=0;i<THREADS;i++){
			pthread_join( threads[i], NULL);
	}
	//pthread_exit(NULL);
}
